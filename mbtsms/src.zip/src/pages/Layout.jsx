// Placeholder for Layout.jsx
// src/pages/Dashboard.jsx

import React from 'react';

const Layout = () => {
  return (
    <div>
      <h1>Welcome to the Layout</h1>
      {/* Your dashboard content here */}
    </div>
  );
};

export default Layout;
