import React from 'react';
import {
  Sidebar,
  Menu,
  MenuItem,
  SubMenu,
} from 'react-pro-sidebar';
import {
  FaChartBar,
  FaMap,
  FaPalette,
  FaCartPlus,
  FaCalendarAlt,
  FaBook,
  FaHeart,
} from 'react-icons/fa';
import { MdExpandMore } from 'react-icons/md';
import { Link } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';

const SidebarMenu = ({ collapsed }) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const menuItems = [
    {
      label: 'Charts',
      icon: <FaChartBar />,
      children: [
        { label: 'Line', path: '/charts/line' },
        { label: 'Bar', path: '/charts/bar' },
      ],
    },
    {
      label: 'Maps',
      icon: <FaMap />,
      children: [
        { label: 'World Map', path: '/maps/world' },
        { label: 'Country Map', path: '/maps/country' },
      ],
    },
    {
      label: 'Theme',
      icon: <FaPalette />,
      children: [
        { label: 'Light', path: '/theme/light' },
        { label: 'Dark', path: '/theme/dark' },
      ],
    },
    {
      label: 'E-commerce',
      icon: <FaCartPlus />,
      children: [
        { label: 'Products', path: '/ecommerce/products' },
        { label: 'Orders', path: '/ecommerce/orders' },
      ],
    },
    {
      label: 'Extra',
      icon: <MdExpandMore />,
      children: [
        { label: 'Calendar', icon: <FaCalendarAlt />, path: '/calendar' },
        { label: 'Documentation', icon: <FaBook />, path: '/docs' },
        { label: 'Examples', icon: <FaHeart />, path: '/examples' },
      ],
    },
  ];

  const itemClass = `
    text-sm font-medium px-1 py-2 transition duration-150 ease-in-out
    ${isDark
      ? 'text-white hover:text-mbts-blue'
      : 'text-mbts-blue hover:bg-transparent hover:text-mbts-dark'
    }
  `;

  const subItemClass = `
    text-sm px-5 pl-6 pr-3 py-1 transition duration-150 ease-in-out
    ${isDark
      ? 'bg-mbts-blue text-white hover:text-mbts-blue'
      : 'text-mbts-blue hover:bg-transparent hover:text-mbts-dark'
    }
  `;

  const sidebarBg = isDark ? 'bg-mbts-blue' : 'bg-white';

  return (
    // When sidebar collapsed, remove inner Link tags inside MenuItem children

    <Sidebar collapsed={collapsed} className={`h-full pt-11 ${sidebarBg}`}>
        <Menu className={`h-full ${sidebarBg}`}>
            {menuItems.map((item, i) => (
            <SubMenu
                key={i}
                label={item.label}
                icon={item.icon}
                className={itemClass}
            >
                {item.children.map((child, j) => (
                <MenuItem
                    key={j}
                    icon={child.icon}
                    component={<Link to={child.path} />}
                    className={subItemClass}
                >
                    {child.label}
                </MenuItem>
                ))}
            </SubMenu>
            ))}
        </Menu>
    </Sidebar>
  );
};

const SidebarWrapper = ({ collapsed }) => {
  const { theme } = useTheme();
  const wrapperClass = theme === 'dark'
    ? 'bg-mbts-blue text-mbts-light'
    : 'bg-white text-mbts-dark';

  return (
    <div className={`h-screen ${wrapperClass}`}>
      <SidebarMenu collapsed={collapsed} />
    </div>
  );
};

export default SidebarWrapper;
