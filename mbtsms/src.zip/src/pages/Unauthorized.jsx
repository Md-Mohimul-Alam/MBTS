// Placeholder for Unauthorized.jsx
